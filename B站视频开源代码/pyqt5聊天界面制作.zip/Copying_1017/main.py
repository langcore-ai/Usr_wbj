import sys
import threading

from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import Qt, QPropertyAnimation, QRect, QEasingCurve
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QMainWindow, QApplication, QDesktopWidget

from main1030 import Ui_MainWindow


class MyMainForm(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.start_x = None
        self.start_y = None
        self.fixed_width = 710
        self.fixed_height = 569
        self.float_width = 357
        self.float_height = 75
        self.float_right_x = 14  # 右侧距离
        self.float_y = 113  # Y距离
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setWindowFlags(Qt.FramelessWindowHint)  # 设置窗口标志：隐藏窗口边框
        self.animation_event = threading.Event()  # 动画信号
        self.float_state_event = threading.Event()  # 状态信号
        self.widget_3.setMaximumWidth(0)
        self.frame_2.setMaximumSize(0, 0)
        self.setGeometry(QRect(0, 0, 357, 75))
        self.pushButton_2.clicked.connect(self.widget_animation_start)
        self.pushButton.clicked.connect(self.float_animation_exit)
        self.float_animation_start()

    def notice_small(self):
        self.frame.setMaximumSize(16777, 16777)
        self.frame_2.setMaximumSize(0, 0)

    def notice_big(self):
        self.frame.setMaximumSize(0, 0)
        self.frame_2.setMaximumSize(16777, 16777)

    def widget_animation_start(self):
        if self.animation_event.is_set():
            return
        else:
            if self.widget_3.maximumWidth() == 0:
                self.widget_style_right(self.pushButton_2)
                self.animation_event.set()
                widget = QPropertyAnimation(self.widget_3, b"maximumWidth", self)
                widget.setStartValue(0)
                widget.setEndValue(200)
                widget.setEasingCurve(QEasingCurve.OutElastic)  # 弹性动画
                widget.setDuration(400)
                widget.finished.connect(self.widget_animation_start_Signal)
                widget.start()
            else:
                self.widget_style_left(self.pushButton_2)
                self.animation_event.set()
                widget = QPropertyAnimation(self.widget_3, b"maximumWidth", self)
                widget.setStartValue(200)
                widget.setEndValue(0)
                widget.setDuration(400)
                widget.finished.connect(self.widget_animation_start_Signal)
                widget.start()

    def widget_animation_start_Signal(self):
        self.animation_event.clear()
        print(self.widget_3.maximumWidth())

    def float_animation_start(self):
        """主页"""
        if self.animation_event.is_set():
            return
        else:
            self.animation_event.set()
            if self.float_state_event.is_set():
                self.notice_small()
                notice = QPropertyAnimation(self, b"geometry", self)
                notice.setStartValue(
                    QRect(QDesktopWidget().screenGeometry().width() + self.float_width, self.float_y, self.float_width,
                          self.float_height))
                notice.setEndValue(
                    QRect(QDesktopWidget().screenGeometry().width() - self.float_width - self.float_right_x,
                          self.float_y, self.float_width, self.float_height))
                notice.setDuration(800)
                notice.finished.connect(self.float_animation_start_Signal)
                notice.setEasingCurve(QEasingCurve.OutElastic)  # 弹性动画
                notice.start()

                notice = QPropertyAnimation(self, b"windowOpacity", self)
                notice.setStartValue(0)
                notice.setEndValue(1)
                notice.setDuration(200)
                notice.start()
            else:
                self.notice_big()
                notice = QPropertyAnimation(self, b"geometry", self)
                notice.setStartValue(QRect(self.x(), self.y(), 0, 0))
                notice.setEndValue(QRect(self.x(), self.y(), self.fixed_width, self.fixed_height))
                notice.setDuration(400)
                notice.setEasingCurve(QEasingCurve.OutElastic)  # 弹性动画
                notice.finished.connect(self.float_animation_start_Signal)
                notice.start()

                notice = QPropertyAnimation(self, b"windowOpacity", self)
                notice.setStartValue(0)
                notice.setEndValue(1)
                notice.setDuration(200)
                notice.start()

    def float_animation_start_Signal(self):
        self.animation_event.clear()

    def float_animation_exit(self):
        if self.animation_event.is_set():
            return
        else:
            self.animation_event.set()
            if self.float_state_event.is_set():
                notice = QPropertyAnimation(self, b"geometry", self)
                notice.setStartValue(QRect(self.x(), self.y(), self.float_width, self.float_height))
                notice.setEndValue(
                    QRect(self.x() + self.float_width + 24, self.y(), self.float_width, self.float_height))
                notice.setEasingCurve(QEasingCurve.OutElastic)  # 弹性动画
                notice.setDuration(800)
                notice.finished.connect(self.float_animation_exit_Signal)
                notice.start()
            else:
                notice = QPropertyAnimation(self, b"windowOpacity", self)
                notice.setStartValue(1)
                notice.setEndValue(0)
                notice.setDuration(800)
                notice.finished.connect(self.float_animation_exit_Signal)
                notice.start()

    def float_animation_exit_Signal(self):
        self.animation_event.clear()
        self.close()

    def float_recovery_animation(self):
        """复原"""
        if self.animation_event.is_set():
            return
        else:
            self.notice_small()
            self.animation_event.set()
            notice = QPropertyAnimation(self, b"geometry", self)
            notice.setStartValue(QRect(self.x(), self.y(), self.width(), self.height()))
            notice.setEndValue(
                QRect(QDesktopWidget().screenGeometry().width() - self.float_width - self.float_right_x, self.float_y,
                      self.float_width, self.float_height))
            notice.setDuration(800)
            notice.setEasingCurve(QEasingCurve.OutElastic)  # 弹性动画
            notice.finished.connect(self.animation_event.clear)
            notice.start()

    def float_deformation_animation(self):
        """变形"""
        if self.animation_event.is_set():
            return
        else:
            self.notice_big()
            self.animation_event.set()
            notice = QPropertyAnimation(self, b"geometry", self)
            notice.setStartValue(QRect(self.x(), self.y(), self.float_width, self.float_height))
            notice.setEndValue(QRect(self.x(), self.y(), self.fixed_width, self.fixed_height))
            notice.setDuration(400)
            notice.setEasingCurve(QEasingCurve.OutElastic)  # 弹性动画
            notice.finished.connect(self.animation_event.clear)
            notice.start()

    def mouseReleaseEvent(self, event):
        if self.animation_event.is_set():
            return
        else:
            if self.float_state_event.is_set():
                if self.x() > QDesktopWidget().screenGeometry().width() / 5 * 4:
                    if self.animation_event.is_set():
                        return
                    self.float_recovery_animation()
                    self.float_state_event.set()
                else:
                    if self.animation_event.is_set():
                        return
                    self.float_deformation_animation()
                    self.float_state_event.clear()
            else:
                if self.x() + self.width() > QDesktopWidget().screenGeometry().width() / 10 * 9:
                    if self.animation_event.is_set():
                        return
                    self.float_recovery_animation()
                    self.float_state_event.set()

            self.start_x = None
            self.start_y = None

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            super(MyMainForm, self).mousePressEvent(event)
            self.start_x = event.x()
            self.start_y = event.y()

    def mouseMoveEvent(self, event):
        if self.animation_event.is_set():
            return
        else:
            try:
                super(MyMainForm, self).mouseMoveEvent(event)
                dis_x = event.x() - self.start_x
                dis_y = event.y() - self.start_y
                self.move(self.x() + dis_x, self.y() + dis_y)
            except:
                pass

    @staticmethod
    def widget_style_left(widget):
        style = """QPushButton{
            margin-right:3px;
            margin-bottom:0px;
            color: rgb(255, 255, 255);
            image: url(:/buttom/img/buttom/双左_double-left.svg);
            border:1px outset rgb(255, 255, 255);
            border-radius:8px;
        }
        QPushButton:hover {
        
        border:2px outset rgba(36, 36, 36,0);
        }
        QPushButton:pressed {
        
        border:4px outset rgba(36, 36, 36,0);
        }"""
        widget.setStyleSheet(style)


    @staticmethod
    def widget_style_right(widget):
        style = """QPushButton{
            margin-right:3px;
            margin-bottom:0px;
            color: rgb(255, 255, 255);
            image: url(:/buttom/img/buttom/双右_double-right.svg);
            border:1px outset rgb(255, 255, 255);
            border-radius:8px;
        }
        QPushButton:hover {

        border:2px outset rgba(36, 36, 36,0);
        }
        QPushButton:pressed {

        border:4px outset rgba(36, 36, 36,0);
        }"""
        widget.setStyleSheet(style)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWin = MyMainForm()
    myWin.show()
    sys.exit(app.exec_())
